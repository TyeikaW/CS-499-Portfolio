package com.example.eventtrackingapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;

import java.util.ArrayList;

public class DataActivity extends AppCompatActivity {
    ArrayList<String> dataList = new ArrayList<>();
    ArrayAdapter<String> adapter;
    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Connect UI elements
        GridView dataGrid = findViewById(R.id.dataGrid);
        EditText addItemField = findViewById(R.id.addItemField);
        Button addButton = findViewById(R.id.addButton);

        // Setup adapter for GridView
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, dataList);
        dataGrid.setAdapter(adapter);

        // Load events from database
        loadEventsFromDatabase();

        // Add new event
        addButton.setOnClickListener(v -> {
            String newItem = addItemField.getText().toString().trim();
            if (!newItem.isEmpty()) {
                if (dbHelper.addEvent(newItem)) {
                    dataList.add(newItem);
                    adapter.notifyDataSetChanged();
                    addItemField.setText("");
                }
            }
        });

        // Long press to delete event
        dataGrid.setOnItemLongClickListener((parent, view, position, id) -> {
            String itemName = dataList.get(position);
            int eventId = getEventIdByName(itemName);
            if (dbHelper.deleteEvent(eventId)) {
                dataList.remove(position);
                adapter.notifyDataSetChanged();
            }
            return true;
        });

        // Click to go to SMSActivity
        dataGrid.setOnItemClickListener((parent, view, position, id) -> {
            Intent smsIntent = new Intent(DataActivity.this, SMSActivity.class);
            startActivity(smsIntent);
        });
    }

    // Load events from database into GridView
    private void loadEventsFromDatabase() {
        Cursor cursor = dbHelper.getAllEvents();
        if (cursor != null) {
            while (cursor.moveToNext()) {
                dataList.add(cursor.getString(cursor.getColumnIndexOrThrow("name")));
            }
            adapter.notifyDataSetChanged();
            cursor.close();
        }
    }

    // Get event ID by its name
    private int getEventIdByName(String name) {
        Cursor cursor = dbHelper.getAllEvents();
        int id = -1;
        if (cursor != null) {
            while (cursor.moveToNext()) {
                if (cursor.getString(cursor.getColumnIndexOrThrow("name")).equals(name)) {
                    id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                    break;
                }
            }
            cursor.close();
        }
        return id;
    }
}

